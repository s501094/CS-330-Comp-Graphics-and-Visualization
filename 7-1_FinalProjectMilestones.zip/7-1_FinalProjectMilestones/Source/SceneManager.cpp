///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>
#include <vector>
#include <direct.h>

// declare the global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 * SceneManager()
 *
 * The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 * ~SceneManager()
 *
 * The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 * CreateGLTexture()
 *
 * This method is used for loading textures from image files,
 * configuring the texture mapping parameters in OpenGL,
 * generating the mipmaps, and loading the read texture into
 * the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;
	unsigned char* image = nullptr;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// Define all possible paths to check
	std::vector<std::string> pathsToCheck;
	pathsToCheck.push_back(std::string(filename));
	pathsToCheck.push_back("images/" + std::string(filename));
	pathsToCheck.push_back("../images/" + std::string(filename));
	pathsToCheck.push_back("../../images/" + std::string(filename));

	std::string usedPath = "";

	// Try each path until one works
	for (const auto& path : pathsToCheck)
	{
		image = stbi_load(path.c_str(), &width, &height, &colorChannels, 0);
		if (image)
		{
			usedPath = path;
			break;
		}
	}

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "SUCCESS: Loaded texture [" << tag << "] from " << usedPath << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "FATAL ERROR: Could not find image " << filename << " in any checked location." << std::endl;
	return false;
}

/***********************************************************
 * BindGLTextures()
 *
 * This method is used for binding the loaded textures to
 * OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 * DestroyGLTextures()
 *
 * This method is used for freeing the memory in all the
 * used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 * FindTextureID()
 *
 * This method is used for getting an ID for the previously
 * loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 * FindTextureSlot()
 *
 * This method is used for getting a slot index for the previously
 * loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 * FindMaterial()
 *
 * This method is used for getting a material from the previously
 * defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 * SetTransformations()
 *
 * This method is used for setting the transform buffer
 * using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 * SetShaderColor()
 *
 * This method is used for setting the passed in color
 * into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 * SetShaderTexture()
 *
 * This method is used for setting the texture data
 * associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 * SetTextureUVScale()
 *
 * This method is used for setting the texture UV scale
 * values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 * SetShaderMaterial()
 *
 * This method is used for passing the material values
 * into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 * DefineObjectMaterials()
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Plastic Material (Keys)
	OBJECT_MATERIAL plastic;
	plastic.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	plastic.ambientStrength = 0.2f;
	// Lighter Grey (0.6) so it catches more color
	plastic.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	plastic.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	plastic.shininess = 32.0f;
	plastic.tag = "plastic";
	m_objectMaterials.push_back(plastic);

	// Metal Material (Base)
	OBJECT_MATERIAL metal;
	metal.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	metal.ambientStrength = 0.3f;
	metal.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	metal.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	metal.shininess = 64.0f;
	metal.tag = "metal";
	m_objectMaterials.push_back(metal);

	// Wood Material (Desk)
	OBJECT_MATERIAL wood;
	wood.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	wood.ambientStrength = 0.4f;
	wood.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	wood.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	wood.shininess = 4.0f;
	wood.tag = "wood";
	m_objectMaterials.push_back(wood);
}

/***********************************************************
 * SetupSceneLights()
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// ---------------------------------------------------------
	// LIGHT 1: CYAN (Left Side) - Main Light
	// ---------------------------------------------------------
	// Position: Y=6.0, Z=8.0 (Good desk lamp angle)
	m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(-6.0f, 6.0f, 8.0f));

	// Ambient: Dark Cyan tint
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.0f, 0.2f, 0.2f));

	// Diffuse: Cyan
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.0f, 1.0f, 1.0f));

	// Specular: Cyan
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(0.0f, 1.0f, 1.0f));

	// Intensity: Strong enough to glow
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 4.0f);


	// ---------------------------------------------------------
	// LIGHT 2: PURPLE (Right Side) - Fill Light
	// ---------------------------------------------------------
	m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(6.0f, 6.0f, 8.0f));

	// Ambient: Dark Purple tint
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.2f, 0.0f, 0.2f));

	// Diffuse: Magenta
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(1.0f, 0.0f, 1.0f));

	// Specular: Magenta
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(1.0f, 0.0f, 1.0f));

	// Intensity
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 4.0f);
}

/***********************************************************
 * LoadSceneTextures()
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	bReturn = CreateGLTexture("Deskwood.jpg", "desk");
	bReturn = CreateGLTexture("keyboardbase.jpg", "base");
	bReturn = CreateGLTexture("keyboardswitchcolor.jpg", "plate");
	bReturn = CreateGLTexture("spacekey.jpg", "space");
	bReturn = CreateGLTexture("enterkey.jpg", "enter");
	bReturn = CreateGLTexture("esckey.jpg", "esc");

	BindGLTextures();
}

/***********************************************************
 * PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
	DefineObjectMaterials();
	SetupSceneLights();
	LoadSceneTextures();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();

	// NEW: Load Sphere and Cylinder for Mouse and Mug
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
}

/***********************************************************
 * RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// ---------------------------------------------------------
	// 1. DESK (Rotated 10 Degrees) - PLANE MESH
	// ---------------------------------------------------------
	scaleXYZ = glm::vec3(20.0f, 10.0f, 15.0f);
	XrotationDegrees = 10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, -0.2f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(1, 1, 1, 1);
	SetShaderMaterial("wood");
	SetShaderTexture("desk");
	SetTextureUVScale(4.0f, 4.0f);

	m_basicMeshes->DrawPlaneMesh();

	// ---------------------------------------------------------
	// 2. KEYBOARD BASE - BOX MESH
	// ---------------------------------------------------------
	scaleXYZ = glm::vec3(9.4f, 0.5f, 3.0f);
	XrotationDegrees = 10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Raised Y to -0.25f (was -1.95) because the desk is flatter
	positionXYZ = glm::vec3(0.0f, -0.25f, 2.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(0.8f, 0.8f, 0.8f, 1.0f);
	SetShaderMaterial("metal");
	SetShaderTexture("base");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------
	// 3. KEYBOARD PLATE - BOX MESH
	// ---------------------------------------------------------
	scaleXYZ = glm::vec3(8.9f, 0.3f, 2.4f);
	XrotationDegrees = 10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.1f, 2.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(0.8f, 0.8f, 0.8f, 1.0f);
	SetShaderMaterial("plastic");
	SetShaderTexture("plate");

	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------
	// 4. KEY GENERATION - BOX MESHES
	// ---------------------------------------------------------

	// START POS (Aligned to ESC key)
	glm::vec3 keyStartPos = glm::vec3(-4.0f, 0.45f, 1.15f);

	float keySpacing = 0.62f;
	float rowSpacing = 0.616f;

	// SLOPE: Tangent of 10 degrees is small (~0.17)
	float slopeDrop = 0.09f;

	SetShaderColor(0.8f, 0.8f, 0.8f, 1.0f);
	SetShaderMaterial("plastic");
	SetShaderTexture("base");

	for (int row = 0; row < 4; row++)
	{
		for (int col = 0; col < 13; col++)
		{
			// Skip ESC
			if (row == 0 && col == 0) continue;

			// Skip ENTER
			if ((row == 1 || row == 2) && col > 10) continue;

			// Skip SPACEBAR
			if (row == 3 && col >= 3 && col <= 8) continue;

			scaleXYZ = glm::vec3(0.5f, 0.25f, 0.4f);
			XrotationDegrees = 10.0f;

			float stagger = (row * 0.2f);

			// Slope drop logic
			float currentY = keyStartPos.y - (row * slopeDrop);
			float currentZ = keyStartPos.z + (row * rowSpacing);
			float currentX = keyStartPos.x + (col * keySpacing) + stagger;

			positionXYZ = glm::vec3(currentX, currentY, currentZ);

			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();
		}
	}

	// ---------------------------------------------------------
	// 5. SPECIAL KEYS - BOX MESHES
	// ---------------------------------------------------------

	// ESCAPE KEY
	scaleXYZ = glm::vec3(0.5f, 0.25f, 0.4f);
	XrotationDegrees = 10.0f;
	positionXYZ = glm::vec3(-3.95f, 0.45f, 1.15f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("esc");
	m_basicMeshes->DrawBoxMesh();

	// SPACEBAR
	scaleXYZ = glm::vec3(3.5f, 0.25f, 0.4f);
	XrotationDegrees = 10.0f;
	positionXYZ = glm::vec3(0.0f, 0.18f, 3.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("space");
	m_basicMeshes->DrawBoxMesh();

	// ENTER KEY
	scaleXYZ = glm::vec3(0.9f, 0.25f, 0.4f);
	XrotationDegrees = 10.0f;
	positionXYZ = glm::vec3(3.75f, 0.32f, 1.75f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("enter");
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------
	// 6. COMPUTER MOUSE (Right Side) - SPHERE MESH
	// ---------------------------------------------------------
	// Shape: SPHERE (Distorted to look like an oval mouse)
	scaleXYZ = glm::vec3(1.2f, 0.6f, 2.0f);

	XrotationDegrees = 10.0f; // Match Desk Tilt
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: Right of keyboard (X=10), Sitting on desk slope
	positionXYZ = glm::vec3(10.0f, -0.4f, 2.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f); // Dark Grey
	SetShaderMaterial("plastic"); // Glossy
	SetShaderTexture("base"); // Dark grip texture

	m_basicMeshes->DrawSphereMesh();


	// ---------------------------------------------------------
	// 7. COFFEE MUG (Left Side) - CYLINDER MESH
	// ---------------------------------------------------------
	// Shape: CYLINDER
	scaleXYZ = glm::vec3(1.0f, 2.5f, 1.0f);

	XrotationDegrees = 10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: Left of keyboard (X=-10)
	positionXYZ = glm::vec3(-10.0f, -0.5f, 2.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f); // White
	SetShaderMaterial("plastic"); // Ceramic look
	SetShaderTexture("plate"); // White texture

	m_basicMeshes->DrawCylinderMesh();


// ---------------------------------------------------------
// 9. COFFEE MUG HANDLE (Standing up) - BOX MESH
// ---------------------------------------------------------
// Shape: BOX (Thin and tall)
	scaleXYZ = glm::vec3(.2f, 1.3f, 1.1f);

	// Tilted forward slightly (10 degrees absolute so it aligns with the mug)
	XrotationDegrees = 10.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// Position: Side of mug base
	positionXYZ = glm::vec3(-9.0f, .8f, 2.3f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f); // White screen
	SetShaderMaterial("plastic");
	SetShaderTexture("plate"); // White texture

	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------
	// 8. LAPTOP BASE (Behind keyboard) - BOX MESH
	// ---------------------------------------------------------
	// Shape: BOX (Flattened)
	scaleXYZ = glm::vec3(12.0f, 0.3f, 7.0f);

	XrotationDegrees = 10.0f; // Match Desk
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: Behind keyboard (Z=-6.0)
	positionXYZ = glm::vec3(0.0f, 1.04f, -6.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f); // Dark Grey
	SetShaderMaterial("metal");
	SetShaderTexture("base");

	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------
	// 9. LAPTOP SCREEN (Standing up) - BOX MESH
	// ---------------------------------------------------------
	// Shape: BOX (Thin and tall)
	scaleXYZ = glm::vec3(12.0f, 6.0f, 0.2f);

	// Tilted back slightly (-10 degrees absolute looks like an open screen relative to the 10 degree desk)
	XrotationDegrees = -5.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: Top edge of laptop base
	positionXYZ = glm::vec3(0.0f, 4.7f, -9.5f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f); // White screen
	SetShaderMaterial("plastic");
	SetShaderTexture("plate"); // White texture

	m_basicMeshes->DrawBoxMesh();
}
/*
 * CS 330 Module Eight Assignment
 * 2D Physics Animation
 *
 * This program implements a 2D scene with:
 * 1. Vector-based physics reflection (Angle of Incidence = Angle of Reflection).
 * 2. Destructible bricks with health states (Color changes on hit).
 * 3. Circle-Circle interaction (Color changes on collision).
 * 4. Procedural Brick Grid layout.
 */

#include <GLFW/glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>
#include <cmath> // Needed for sqrt

using namespace std;

const float DEG2RAD = 3.14159 / 180;

void processInput(GLFWwindow* window);

// Brick type enum
enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

// --------------------------------------------------------
// BRICK CLASS
// --------------------------------------------------------
class Brick
{
public:
    float red, green, blue;
    float x, y, width, height;
    BRICKTYPE brick_type;
    ONOFF onoff;
    int hitPoints; // New: Bricks have health

    Brick(BRICKTYPE bt, float xx, float yy, float ww, float hh, float rr, float gg, float bb)
    {
        brick_type = bt;
        x = xx;
        y = yy;
        width = ww;
        height = hh;
        red = rr;
        green = gg;
        blue = bb;
        onoff = ON;
        hitPoints = 3; // Bricks take 3 hits to destroy
    };

    void drawBrick()
    {
        if (onoff == ON)
        {
            double halfWidth = width / 2;
            double halfHeight = height / 2;

            // CHANGE STATE: Color darkens as health decreases
            float healthFactor = (float)hitPoints / 3.0f;
            glColor3d(red * healthFactor, green * healthFactor, blue * healthFactor);

            glBegin(GL_POLYGON);
            glVertex2d(x + halfWidth, y + halfHeight);
            glVertex2d(x + halfWidth, y - halfHeight);
            glVertex2d(x - halfWidth, y - halfHeight);
            glVertex2d(x - halfWidth, y + halfHeight);
            glEnd();
        }
    }
};

// --------------------------------------------------------
// CIRCLE CLASS
// --------------------------------------------------------
class Circle
{
public:
    float red, green, blue;
    float radius;
    float x, y;
    float vx, vy; // New: Velocity Vector (Physics based movement)

    Circle(double xx, double yy, double rr, float vx_init, float vy_init, float r, float g, float b)
    {
        x = xx;
        y = yy;
        radius = rr;
        vx = vx_init;
        vy = vy_init;
        red = r;
        green = g;
        blue = b;
    }

    // Logic to check collision with a brick
    void CheckCollision(Brick* brk)
    {
        if (brk->onoff == OFF) return;

        // Simple AABB Collision detection (Circle treated as box for simplicity in this specific framework)
        bool collisionX = x + radius >= brk->x - brk->width / 2 &&
            x - radius <= brk->x + brk->width / 2;

        bool collisionY = y + radius >= brk->y - brk->height / 2 &&
            y - radius <= brk->y + brk->height / 2;

        if (collisionX && collisionY)
        {
            // PHYSICS: Reflect velocity
            // Determine if we hit the side or top/bottom based on previous position (simplified)
            // For this assignment, simply reversing Y covers most "breakout" style interactions
            vy = -vy;

            if (brk->brick_type == DESTRUCTABLE)
            {
                // ALTER STATE: Reduce health
                brk->hitPoints--;
                if (brk->hitPoints <= 0) {
                    brk->onoff = OFF;
                }
            }
        }
    }

    // Check collision with other circles
    void CheckCircleCollision(Circle* other)
    {
        // Distance formula
        float dx = x - other->x;
        float dy = y - other->y;
        float distance = sqrt(dx * dx + dy * dy);

        if (distance < radius + other->radius)
        {
            // ALTER STATE: Change color on collision
            red = (rand() % 100) / 100.0f;
            green = (rand() % 100) / 100.0f;
            blue = (rand() % 100) / 100.0f;

            other->red = (rand() % 100) / 100.0f;
            other->green = (rand() % 100) / 100.0f;
            other->blue = (rand() % 100) / 100.0f;

            // Basic bounce response (separating them)
            vx = -vx;
            vy = -vy;
            other->vx = -other->vx;
            other->vy = -other->vy;
        }
    }

    void MoveOneStep()
    {
        // Apply Velocity
        x += vx;
        y += vy;

        // PHYSICS: Wall Bouncing (Inverse Velocity)
        // Right Wall
        if (x + radius > 1.0f) {
            x = 1.0f - radius;
            vx = -vx;
        }
        // Left Wall
        if (x - radius < -1.0f) {
            x = -1.0f + radius;
            vx = -vx;
        }
        // Top Wall
        if (y + radius > 1.0f) {
            y = 1.0f - radius;
            vy = -vy;
        }
        // Bottom Wall
        if (y - radius < -1.0f) {
            y = -1.0f + radius;
            vy = -vy;
        }
    }

    void DrawCircle()
    {
        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        for (int i = 0; i < 360; i++) {
            float degInRad = i * DEG2RAD;
            glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
        }
        glEnd();
    }
};

// Global containers
vector<Circle> world;
vector<Brick> bricks;

int main(void) {
    srand(time(NULL));

    if (!glfwInit()) {
        exit(EXIT_FAILURE);
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    GLFWwindow* window = glfwCreateWindow(600, 600, "8-2 Assignment", NULL, NULL); // Increased size slightly
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    // --------------------------------------------------------
    // SETUP: Create a Grid of Bricks
    // --------------------------------------------------------
    float startX = -0.8f;
    float startY = 0.8f;
    float brickW = 0.3f;
    float brickH = 0.1f;
    float gap = 0.05f;

    for (int row = 0; row < 4; row++) {
        for (int col = 0; col < 5; col++) {
            float bx = startX + (col * (brickW + gap));
            float by = startY - (row * (brickH + gap));

            // Varied colors based on row
            float r = (row == 0 || row == 3) ? 1.0f : 0.2f;
            float g = (row == 1) ? 1.0f : 0.2f;
            float b = (row == 2) ? 1.0f : 0.2f;

            Brick newBrick(DESTRUCTABLE, bx, by, brickW, brickH, r, g, b);
            bricks.push_back(newBrick);
        }
    }

    while (!glfwWindowShouldClose(window)) {
        //Setup View
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float)height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);

        processInput(window);

        // ----------------------------------------------------
        // LOGIC UPDATE LOOP
        // ----------------------------------------------------

        // 1. Move Circles & Check Wall Collisions
        for (int i = 0; i < world.size(); i++)
        {
            world[i].MoveOneStep();
            world[i].DrawCircle();
        }

        // 2. Check Circle-Brick Collisions
        for (int i = 0; i < world.size(); i++)
        {
            for (int j = 0; j < bricks.size(); j++) {
                world[i].CheckCollision(&bricks[j]);
            }
        }

        // 3. Check Circle-Circle Collisions (Interaction)
        for (int i = 0; i < world.size(); i++)
        {
            for (int j = i + 1; j < world.size(); j++) {
                world[i].CheckCircleCollision(&world[j]);
            }
        }

        // 4. Draw Bricks
        for (int i = 0; i < bricks.size(); i++) {
            bricks[i].drawBrick();
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate(); // Fixed syntax error from original (missing parenthesis)
    exit(EXIT_SUCCESS);
}


void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    // Spacebar spawns a new circle
    static bool spacePressed = false; // Simple debounce
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
    {
        if (!spacePressed) {
            double r = (rand() % 100) / 100.0;
            double g = (rand() % 100) / 100.0;
            double b = (rand() % 100) / 100.0;

            // Random velocity for physics trajectory
            float vx = ((rand() % 100) / 2000.0f) * (rand() % 2 == 0 ? 1 : -1);
            float vy = ((rand() % 100) / 2000.0f) - 0.02f; // Generally downwards

            // Spawn at bottom center
            Circle B(0, -0.8, 0.05, vx, vy, r, g, b);
            world.push_back(B);
            spacePressed = true;
        }
    }
    else {
        spacePressed = false;
    }
}